import os

print "testWCDB1.py"
#unittest.main()
os.system("python manage.py test")
print "Done."
