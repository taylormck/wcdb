# -*- coding: utf-8 -*-
""" The mandatory models.py to make Django consider this to be an app. """
from django.db import models

